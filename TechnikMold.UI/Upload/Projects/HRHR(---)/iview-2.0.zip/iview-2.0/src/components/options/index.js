import Options from '../page/options.vue';
export default Options;