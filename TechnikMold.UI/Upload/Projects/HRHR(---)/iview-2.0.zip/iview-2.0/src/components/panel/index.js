import Panel from '../collapse/panel.vue';

export default Panel;