import Timeline from './timeline.vue';
import TimelineItem from './timeline-item.vue';

Timeline.Item = TimelineItem;
export default Timeline;