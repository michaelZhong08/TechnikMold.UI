import Step from '../steps/step.vue';

export default Step;